Option Explicit

Dim fso, shell, trayPath, command
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

trayPath = fso.BuildPath(fso.GetParentFolderName(WScript.ScriptFullName), "AltantivirusTray.ps1")
If Not fso.FileExists(trayPath) Then
  WScript.Quit 1
End If

command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Quote(trayPath)
shell.Run command, 0, False

Function Quote(value)
  Quote = Chr(34) & value & Chr(34)
End Function
