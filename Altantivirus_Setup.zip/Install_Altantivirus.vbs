Option Explicit

Dim fso, shell, srcDir, srcApp, srcTray, srcTrayLauncher, srcIcon
Dim installDir, installedApp, installedTray, installedTrayLauncher, installedIcon
Dim desktopShortcut, startMenuDir, startMenuShortcut

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

srcDir = fso.GetParentFolderName(WScript.ScriptFullName)
srcApp = fso.BuildPath(srcDir, "Altantivirus.hta")
srcTray = fso.BuildPath(srcDir, "AltantivirusTray.ps1")
srcTrayLauncher = fso.BuildPath(srcDir, "AltantivirusTrayLauncher.vbs")
srcIcon = fso.BuildPath(srcDir, "Altantivirus.ico")
installDir = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Altantivirus"
installedApp = fso.BuildPath(installDir, "Altantivirus.hta")
installedTray = fso.BuildPath(installDir, "AltantivirusTray.ps1")
installedTrayLauncher = fso.BuildPath(installDir, "AltantivirusTrayLauncher.vbs")
installedIcon = fso.BuildPath(installDir, "Altantivirus.ico")

If Not fso.FileExists(srcApp) Then
  MsgBox "Altantivirus.hta bulunamadi. Kurulum dosyasi uygulama ile ayni klasorde olmali.", vbCritical, "Altantivirus"
  WScript.Quit 1
End If

If Not fso.FileExists(srcTray) Or Not fso.FileExists(srcTrayLauncher) Then
  MsgBox "Sistem tepsisi dosyalari bulunamadi. Kurulum paketi eksik.", vbCritical, "Altantivirus"
  WScript.Quit 1
End If

If Not fso.FileExists(srcIcon) Then
  MsgBox "Altantivirus.ico bulunamadi. Kurulum paketi eksik.", vbCritical, "Altantivirus"
  WScript.Quit 1
End If

If Not fso.FolderExists(installDir) Then
  fso.CreateFolder installDir
End If

fso.CopyFile srcApp, installedApp, True
fso.CopyFile srcTray, installedTray, True
fso.CopyFile srcTrayLauncher, installedTrayLauncher, True
fso.CopyFile srcIcon, installedIcon, True

desktopShortcut = shell.SpecialFolders("Desktop") & "\Altantivirus.lnk"
CreateShortcut desktopShortcut, installedApp

startMenuDir = shell.SpecialFolders("Programs") & "\Altantivirus"
If Not fso.FolderExists(startMenuDir) Then
  fso.CreateFolder startMenuDir
End If
startMenuShortcut = startMenuDir & "\Altantivirus.lnk"
CreateShortcut startMenuShortcut, installedApp

MsgBox "Altantivirus kuruldu. Masaustundeki simgeden acabilirsiniz.", vbInformation, "Altantivirus"
shell.Run "mshta.exe " & Quote(installedApp), 1, False

Sub CreateShortcut(shortcutPath, appPath)
  Dim s
  Set s = shell.CreateShortcut(shortcutPath)
  s.TargetPath = shell.ExpandEnvironmentStrings("%WINDIR%") & "\System32\mshta.exe"
  s.Arguments = Quote(appPath)
  s.WorkingDirectory = fso.GetParentFolderName(appPath)
  s.IconLocation = fso.BuildPath(fso.GetParentFolderName(appPath), "Altantivirus.ico")
  s.Description = "Altantivirus Premium Security"
  s.Save
End Sub

Function Quote(value)
  Quote = Chr(34) & value & Chr(34)
End Function
