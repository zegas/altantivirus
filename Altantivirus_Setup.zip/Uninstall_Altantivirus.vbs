Option Explicit

Dim fso, shell, installDir, desktopShortcut, startMenuDir, startupShortcut
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

installDir = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Altantivirus"
desktopShortcut = shell.SpecialFolders("Desktop") & "\Altantivirus.lnk"
startMenuDir = shell.SpecialFolders("Programs") & "\Altantivirus"
startupShortcut = shell.SpecialFolders("Startup") & "\Altantivirus.lnk"

On Error Resume Next
StopGuard
StopTray
If fso.FileExists(desktopShortcut) Then fso.DeleteFile desktopShortcut, True
If fso.FileExists(startupShortcut) Then fso.DeleteFile startupShortcut, True
If fso.FolderExists(startMenuDir) Then fso.DeleteFolder startMenuDir, True
If fso.FolderExists(installDir) Then fso.DeleteFolder installDir, True
On Error GoTo 0

MsgBox "Altantivirus kaldirildi.", vbInformation, "Altantivirus"

Sub StopGuard()
  Dim wmi, processes, p, cmd
  Set wmi = GetObject("winmgmts:\\.\root\cimv2")
  Set processes = wmi.ExecQuery("Select * from Win32_Process where Name='wscript.exe' or Name='cscript.exe'")
  For Each p In processes
    cmd = LCase(CStr(p.CommandLine))
    If InStr(cmd, "altantivirusguard.vbs") > 0 Then p.Terminate
  Next
End Sub

Sub StopTray()
  Dim wmi, processes, p, cmd
  Set wmi = GetObject("winmgmts:\\.\root\cimv2")
  Set processes = wmi.ExecQuery("Select * from Win32_Process where Name='powershell.exe' or Name='pwsh.exe'")
  For Each p In processes
    cmd = LCase(CStr(p.CommandLine))
    If InStr(cmd, "altantivirustray.ps1") > 0 Then p.Terminate
  Next
End Sub
