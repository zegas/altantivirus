Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$mutexName = "Global\AltantivirusTray"
$created = $false
$mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$created)
if (-not $created) { return }

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$appPath = Join-Path $appDir "Altantivirus.hta"
$appData = Join-Path $env:APPDATA "Altantivirus"
$settingsPath = Join-Path $appData "settings.ini"
$quarantineDir = Join-Path $appData "Quarantine"
$logPath = Join-Path $appData "background.log"
$downloadPath = Join-Path $env:USERPROFILE "Downloads"
$recentEvents = @{}

if (-not (Test-Path $appData)) { New-Item -ItemType Directory -Path $appData | Out-Null }
if (-not (Test-Path $quarantineDir)) { New-Item -ItemType Directory -Path $quarantineDir | Out-Null }

function Get-Settings {
  $settings = @{
    realtime = "true"
  }
  if (Test-Path $settingsPath) {
    Get-Content $settingsPath -ErrorAction SilentlyContinue | ForEach-Object {
      $p = $_.IndexOf("=")
      if ($p -gt 0) {
        $settings[$_.Substring(0, $p)] = $_.Substring($p + 1)
      }
    }
  }
  return $settings
}

function Save-Settings($settings) {
  $lines = New-Object System.Collections.Generic.List[string]
  foreach ($key in $settings.Keys) {
    $lines.Add("$key=$($settings[$key])")
  }
  Set-Content -Path $settingsPath -Value $lines -Encoding ASCII
}

function Is-RealtimeOn {
  $s = Get-Settings
  return (-not $s.ContainsKey("realtime")) -or $s["realtime"] -eq "true"
}

function Set-Realtime($enabled) {
  $s = Get-Settings
  $s["realtime"] = $(if ($enabled) { "true" } else { "false" })
  Save-Settings $s
}

function Start-Guard {
  Enable-DefenderRealtime
  $scanTimer.Enabled = $true
  if ($downloadWatcher) { $downloadWatcher.EnableRaisingEvents = $true }
}

function Stop-Guard {
  $scanTimer.Enabled = $false
  if ($downloadWatcher) { $downloadWatcher.EnableRaisingEvents = $false }
}

function Open-App {
  if (Test-Path $appPath) {
    Start-Process -FilePath "mshta.exe" -ArgumentList "`"$appPath`""
  }
}

function Open-Quarantine {
  Start-Process -FilePath "explorer.exe" -ArgumentList "`"$quarantineDir`""
}

function Update-Menu {
  $enabled = Is-RealtimeOn
  $notify.Text = $(if ($enabled) { "Altantivirus - koruma aktif" } else { "Altantivirus - koruma duraklatildi" })
  $toggleItem.Text = $(if ($enabled) { "Korumayi Durdur" } else { "Korumayi Baslat" })
  $stateItem.Text = $(if ($enabled) { "Durum: Koruma aktif" } else { "Durum: Koruma kapali" })
  if ($enabled) {
    $notify.Icon = [System.Drawing.SystemIcons]::Shield
  } else {
    $notify.Icon = [System.Drawing.SystemIcons]::Warning
  }
}

function Write-Log($message) {
  Add-Content -Path $logPath -Value "$((Get-Date).ToString('s')) - $message" -Encoding ASCII
}

function Enable-DefenderRealtime {
  try {
    Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
    Set-MpPreference -PUAProtection Enabled -ErrorAction SilentlyContinue
    Write-Log "Microsoft Defender realtime requested."
  } catch {
    Write-Log "Microsoft Defender realtime request failed."
  }
}

function Get-DefenderThreatKeys {
  $keys = @{}
  try {
    Get-MpThreatDetection -ErrorAction SilentlyContinue | ForEach-Object {
      $name = ""
      if ($_.ThreatName) { $name = [string]$_.ThreatName }
      $resources = @()
      if ($_.Resources) { $resources = @($_.Resources) }
      $key = "$name|$($resources -join '|')"
      if (-not [string]::IsNullOrWhiteSpace($key)) { $keys[$key] = $true }
    }
  } catch {}
  return $keys
}

function Show-ThreatNotification($title, $message) {
  try {
    $notify.ShowBalloonTip(5000, $title, $message, [System.Windows.Forms.ToolTipIcon]::Warning)
  } catch {}
}

function Invoke-DefenderPathScan($path) {
  try {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $before = Get-DefenderThreatKeys
    Start-MpScan -ScanType CustomScan -ScanPath $path -ErrorAction SilentlyContinue
    Write-Log "Microsoft Defender scan completed/requested: $path"
    Start-Sleep -Milliseconds 600
    $detections = Get-MpThreatDetection -ErrorAction SilentlyContinue
    foreach ($d in $detections) {
      $name = if ($d.ThreatName) { [string]$d.ThreatName } else { "Tehdit" }
      $resources = @()
      if ($d.Resources) { $resources = @($d.Resources) }
      $key = "$name|$($resources -join '|')"
      $matchesPath = $false
      foreach ($r in $resources) {
        if ([string]$r -and ([string]$r).ToLowerInvariant().Contains($path.ToLowerInvariant())) {
          $matchesPath = $true
        }
      }
      if ($matchesPath -or (-not $before.ContainsKey($key))) {
        Write-Log "Microsoft Defender detection: $name - $path"
        Show-ThreatNotification "Altantivirus" "Virus benzeri dosya tespit edildi: $name"
        return
      }
    }
  } catch {
    Write-Log "Microsoft Defender scan failed: $path"
  }
}

function Read-Sample($path) {
  try {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $len = [Math]::Min($bytes.Length, 4096)
    return [System.Text.Encoding]::ASCII.GetString($bytes, 0, $len)
  } catch {
    return ""
  }
}

function Test-RiskyFile($path) {
  try {
    $file = Get-Item -LiteralPath $path -ErrorAction Stop
    if ($file.Length -gt 26214400) { return $null }
    $name = $file.Name.ToLowerInvariant()
    $ext = $file.Extension.ToLowerInvariant()
    $sample = (Read-Sample $file.FullName).ToLowerInvariant()
    if ($name.Contains("eicar") -or $sample.Contains("eicar-standard-antivirus-test-file")) {
      return @{ Reason = "EICAR test signature"; High = $true }
    }
    if ($name.Contains("crack") -or $name.Contains("keygen") -or $name.Contains("patcher")) {
      return @{ Reason = "Suspicious file name"; High = $false }
    }
    if ((".vbs .js .jse .ps1 .hta .bat .cmd").Contains($ext) -and ($sample.Contains("downloadstring") -or $sample.Contains("wscript.shell") -or $sample.Contains("powershell -enc") -or $sample.Contains("frombase64string"))) {
      return @{ Reason = "Risky script pattern"; High = $false }
    }
    if ((".exe .scr .bat .cmd .vbs .js .jse .ps1 .msi .hta .dll .com").Contains($ext) -and ($name.Contains(".pdf.") -or $name.Contains(".jpg.") -or $name.Contains(".docx."))) {
      return @{ Reason = "Double extension executable"; High = $true }
    }
  } catch {}
  return $null
}

function Move-ToQuarantine($path, $reason) {
  try {
    if ($path.ToLowerInvariant().Contains("\windows\")) { return }
    $file = Get-Item -LiteralPath $path -ErrorAction Stop
    $target = Join-Path $quarantineDir "$((Get-Date).ToString('yyyyMMddHHmmss'))_$($file.Name).quarantine"
    Move-Item -LiteralPath $file.FullName -Destination $target -Force
    Write-Log "Quarantined: $reason - $target"
  } catch {
    Write-Log "Quarantine failed: $path"
  }
}

function Test-DownloadReady($path) {
  try {
    if (-not (Test-Path -LiteralPath $path)) { return $false }
    $ext = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
    if ((".crdownload .tmp .part .download").Contains($ext)) { return $false }
    $stream = [System.IO.File]::Open($path, "Open", "Read", "None")
    $stream.Close()
    return $true
  } catch {
    return $false
  }
}

function Inspect-Download($path) {
  if (-not (Is-RealtimeOn)) { return }
  if ([string]::IsNullOrWhiteSpace($path)) { return }
  $now = Get-Date
  if ($recentEvents.ContainsKey($path) -and (($now - $recentEvents[$path]).TotalSeconds -lt 4)) { return }
  $recentEvents[$path] = $now
  $attempts = 0
  while ($attempts -lt 8 -and -not (Test-DownloadReady $path)) {
    Start-Sleep -Milliseconds 700
    $attempts++
  }
  if (-not (Test-DownloadReady $path)) { return }
  Invoke-DefenderPathScan $path
  $risk = Test-RiskyFile $path
  if ($risk) {
    Write-Log "Download detection: $($risk.Reason) - $path"
    if ($risk.High) {
      Move-ToQuarantine $path $risk.Reason
      Show-ThreatNotification "Altantivirus" "Virus benzeri indirme karantinaya alindi: $($risk.Reason)"
    } else {
      Show-ThreatNotification "Altantivirus" "Supheli indirme tespit edildi: $($risk.Reason)"
    }
  } else {
    Write-Log "Download checked: $path"
  }
}

function Invoke-BackgroundScan {
  if (-not (Is-RealtimeOn)) { return }
  $roots = @(
    [Environment]::GetFolderPath("Desktop"),
    (Join-Path $env:USERPROFILE "Downloads"),
    [Environment]::GetFolderPath("MyDocuments")
  )
  foreach ($root in $roots) {
    if (-not (Test-Path $root)) { continue }
    Get-ChildItem -LiteralPath $root -File -Recurse -ErrorAction SilentlyContinue |
      Select-Object -First 90 |
      ForEach-Object {
        $risk = Test-RiskyFile $_.FullName
        if ($risk) {
          Write-Log "Detection: $($risk.Reason) - $($_.FullName)"
          if ($risk.High) { Move-ToQuarantine $_.FullName $risk.Reason }
        }
      }
  }
}

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.SystemIcons]::Shield
$notify.Visible = $true
$notify.Text = "Altantivirus"

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$stateItem = $menu.Items.Add("Durum: Koruma aktif")
$stateItem.Enabled = $false
[void]$menu.Items.Add("-")
$openItem = $menu.Items.Add("Altantivirus'u Ac")
$toggleItem = $menu.Items.Add("Korumayi Durdur")
$scanItem = $menu.Items.Add("Hizli Tarama Ekranini Ac")
$quarantineItem = $menu.Items.Add("Karantina Klasoru")
[void]$menu.Items.Add("-")
$exitItem = $menu.Items.Add("Korumayi Kapat ve Cik")

$openItem.add_Click({ Open-App })
$scanItem.add_Click({ Open-App })
$quarantineItem.add_Click({ Open-Quarantine })
$toggleItem.add_Click({
  if (Is-RealtimeOn) {
    Set-Realtime $false
    Stop-Guard
    $notify.ShowBalloonTip(2500, "Altantivirus", "Gercek zamanli koruma durduruldu.", [System.Windows.Forms.ToolTipIcon]::Warning)
  } else {
    Set-Realtime $true
    Start-Guard
    $notify.ShowBalloonTip(2500, "Altantivirus", "Gercek zamanli koruma baslatildi.", [System.Windows.Forms.ToolTipIcon]::Info)
  }
  Update-Menu
})
$exitItem.add_Click({
  Set-Realtime $false
  Stop-Guard
  $notify.Visible = $false
  [System.Windows.Forms.Application]::Exit()
})
$notify.add_DoubleClick({ Open-App })
$notify.ContextMenuStrip = $menu

$scanTimer = New-Object System.Windows.Forms.Timer
$scanTimer.Interval = 7000
$scanTimer.add_Tick({ Invoke-BackgroundScan })

$downloadWatcher = $null
if (Test-Path $downloadPath) {
  $downloadWatcher = New-Object System.IO.FileSystemWatcher
  $downloadWatcher.Path = $downloadPath
  $downloadWatcher.IncludeSubdirectories = $true
  $downloadWatcher.Filter = "*.*"
  $downloadWatcher.NotifyFilter = [System.IO.NotifyFilters]'FileName, LastWrite, Size'
  $downloadWatcher.add_Created({ Inspect-Download $EventArgs.FullPath })
  $downloadWatcher.add_Changed({ Inspect-Download $EventArgs.FullPath })
  $downloadWatcher.add_Renamed({ Inspect-Download $EventArgs.FullPath })
}

Start-Guard
Update-Menu
$notify.ShowBalloonTip(2200, "Altantivirus", "Arka plan korumasi sistem tepsisinde calisiyor.", [System.Windows.Forms.ToolTipIcon]::Info)
[System.Windows.Forms.Application]::Run()

$notify.Dispose()
$mutex.ReleaseMutex()
